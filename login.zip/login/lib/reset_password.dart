// // import 'package:firebase_signin/reusable_widgets/reusable_widget.dart;
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:login/home_screen.dart';
// import 'package:login/signin_screen.dart';
// import 'reusable_widget/reusable_widget.dart';
//
// class ResetPassword extends StatefulWidget {
//   const ResetPassword({Key? key}) : super(key: key);
//
//   @override
//   _ResetPasswordState createState() => _ResetPasswordState();
// }
//
// class _ResetPasswordState extends State<ResetPassword> {
//   TextEditingController _emailTextController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: AppBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         title: const Text(
//           "Reset Password",
//           style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//         ),
//       ),
//       body: Container(
//
//           child: SingleChildScrollView(
//               child: Padding(
//                 padding: EdgeInsets.fromLTRB(20, 120, 20, 0),
//                 child: Column(
//                   children: <Widget>[
//                     const SizedBox(
//                       height: 20,
//                     ),
//                     reusableTextField("Enter Email Id", Icons.person_outline, false,
//                         _emailTextController),
//                     const SizedBox(
//                       height: 20,
//                     ),
//                     firebaseUIButton(context, "Reset Password", () {
//                       FirebaseAuth.instance
//                           .sendPasswordResetEmail(email: _emailTextController.text)
//                           .then((value) => Navigator.of(context).pop());
//                     })
//                   ],
//                 ),
//               ))),
//     );
//   }
// }